import argparse
import sys, os
from pystdf.Importer import STDF2DataFrame
#import pystdf.V4 as V4
import pandas as pd
'''
ap= argparse.ArgumentParser()
ap.add_argument('-i','--Input_Path',required=True ,help="Input STDF Path")
ap.add_argument('-o','--Output_Path',required=True ,help="Out Excel Path")
arg = vars(ap.parse_args())
'''
def toExcel(fout,dfs):
    with pd.ExcelWriter(fout) as writer:
        for k,v in dfs.items():
            v.to_excel(writer, sheet_name=k, index=False
            
fin = "a595.stdf"

def stdfMain(fin)
    fout = 'STDF_toExcel.xlsx'
    dfs= STDF2DataFrame(fin)
    print("Exporting to %s" %fout)
    toExcel(fout,dfs)

stdfMain(fin)   
 
'''if __name__ == "__main__":
    #fin = str(arg['Input_Path'])
    #fout = str(arg['Output_Path'])
    dfs= STDF2DataFrame(fin)
    print("Exporting to %s" %fout)
    toExcel(fout,dfs)
   '''