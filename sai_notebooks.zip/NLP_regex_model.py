import spacy

nlp = spacy.load("en_core_web_sm")

log_lines = [
"01-24 18:54:54.389  1000  1784  4487 E ActivityManager: Failure starting process com.google.android.gms.persistent",
"01-24 18:54:54.389  1000  1784  4487 E ActivityManager: java.lang.SecurityException: Package com.google.android.gms is currently frozen!",
"01-24 18:54:54.389  1000  1784  4487 E ActivityManager:    at com.android.server.pm.PackageManagerService.checkPackageStartable(PackageManagerService.java:4409)",
"01-24 18:54:54.389  1000  1784  4487 E ActivityManager:    at com.android.server.pm.PackageManagerService$IPackageManagerImpl.checkPackageStartable(PackageManagerService.java:4491)",
"01-24 18:54:54.389  1000  1784  4487 E ActivityManager:    at com.android.server.am.ProcessList.startProcessLocked(ProcessList.java:1663)",
"01-24 18:57:47.625  1000  1784 20384 E SettingsToPropertiesMapper:     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)",
"01-24 18:54:54.389  1000  1784  4487 E ActivityManager: Failure starting process com.google.android.gms.persistent",
"01-24 19:02:53.080 10126 17413 21130 W rpp     : java.util.concurrent.TimeoutException: Waited 150 milliseconds (plus 110067 nanoseconds delay)",
"01-24 19:02:53.080 10126 17413 21130 W rpp     :     at derq.get(:com.google.android.gms@230214044@23.02.14 (190400-503200382):34)",
"01-24 19:02:53.080 10126 17413 21130 W rpp     :     at rpp.e(:com.google.android.gms@230214044@23.02.14 (190400-503200382):6)"    
]

def preprocess_log_lines(log_lines):
    # Join all the log lines into a single string for processing
    log_text = " ".join(log_lines)
    
    # Tokenize the log text using spaCy
    doc = nlp(log_text)
    
    # Initialize variables for capturing the current exception and its parts
    current_exception = []
    current_exception_line = ''
    
    # List to store the final extracted Java exceptions
    java_exceptions = []
    
    for token in doc:
        # If the token starts with the timestamp (e.g., "01-24"), it indicates a new exception
        if token.text.startswith("01-"):
            # Append the current exception line if any
            if current_exception_line:
                current_exception.append(current_exception_line.strip())
                current_exception_line = ''
                
            # If there was a previous exception, add it to the list
            if current_exception:
                java_exceptions.append(" ".join(current_exception))
                current_exception = []
        else:
            current_exception_line += token.text + ' '

    # Add the last exception to the list
    if current_exception:
        java_exceptions.append(" ".join(current_exception))
        
    return java_exceptions

java_exceptions = preprocess_log_lines(log_lines)

for exception in java_exceptions:
    print(exception)